
import 'package:flutter/material.dart';
import 'package:untitled_2/values/values.dart';


class AndroidMobile5Widget extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 183, 153, 127),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 282,
              margin: EdgeInsets.only(left: 26),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          left: 0,
                          top: 36,
                          child: Row(
                            children: [
                              Container(
                                width: 24,
                                height: 24,
                                child: Image.asset(
                                  "assets/images/left-arrow-2.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Text(
                                "Light 2",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 20,
                                  letterSpacing: 1.04,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          top: 0,
                          right: 0,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                top: 235,
                                right: 77,
                                child: Container(
                                  width: 53,
                                  height: 47,
                                  decoration: BoxDecoration(
                                    color: AppColors.accentElement,
                                    borderRadius: BorderRadius.all(Radius.circular(23.5)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                top: 142,
                                right: 0,
                                child: Container(
                                  width: 211,
                                  height: 116,
                                  decoration: BoxDecoration(
                                    gradient: Gradients.primaryGradient,
                                    borderRadius: BorderRadius.all(Radius.circular(58)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                top: 0,
                                right: 104,
                                child: Container(
                                  width: 3,
                                  height: 145,
                                  decoration: BoxDecoration(
                                    color: AppColors.secondaryElement,
                                  ),
                                  child: Container(),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 199,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            "Power",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                              letterSpacing: 0.728,
                            ),
                          ),
                        ),
                        Container(
                          height: 36,
                          margin: EdgeInsets.only(top: 8),
                          decoration: BoxDecoration(
                            color: AppColors.primaryElement,
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                width: 34,
                                height: 33,
                                margin: EdgeInsets.only(right: 3),
                                decoration: BoxDecoration(
                                  color: Color.fromARGB(255, 142, 131, 119),
                                  borderRadius: BorderRadius.all(Radius.circular(16.5)),
                                ),
                                child: Container(),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Spacer(),
            Container(
              height: 156,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Container(
                      height: 156,
                      decoration: BoxDecoration(
                        color: AppColors.secondaryBackground,
                        borderRadius: BorderRadius.all(Radius.circular(25)),
                      ),
                      child: Container(),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 48,
                          margin: EdgeInsets.only(left: 26, right: 39, bottom: 12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 205,
                                  height: 46,
                                  margin: EdgeInsets.only(bottom: 1),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Container(
                                        width: 99,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(left: 2),
                                                child: Text(
                                                  "Schedule",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.secondaryText,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 14,
                                                    letterSpacing: 0.728,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 99,
                                                height: 17,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                  children: [
                                                    Align(
                                                      alignment: Alignment.bottomLeft,
                                                      child: Text(
                                                        "From",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.accentText,
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 14,
                                                          letterSpacing: 0.728,
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment.bottomLeft,
                                                      child: Container(
                                                        width: 54,
                                                        height: 17,
                                                        margin: EdgeInsets.only(left: 9),
                                                        child: Stack(
                                                          alignment: Alignment.centerRight,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 20,
                                                              child: Text(
                                                                "6:00",
                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                  color: AppColors.secondaryText,
                                                                  fontWeight: FontWeight.w400,
                                                                  fontSize: 14,
                                                                  letterSpacing: 0.728,
                                                                ),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              right: 0,
                                                              child: Text(
                                                                "PM",
                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                  color: Color.fromARGB(255, 130, 128, 128),
                                                                  fontWeight: FontWeight.w400,
                                                                  fontSize: 12,
                                                                  letterSpacing: 0.624,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Spacer(),
                                      Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Container(
                                          margin: EdgeInsets.only(right: 15),
                                          child: Text(
                                            "To",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.accentText,
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14,
                                              letterSpacing: 0.728,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Container(
                                          width: 63,
                                          height: 17,
                                          child: Row(
                                            children: [
                                              Text(
                                                "11:00",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.secondaryText,
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 14,
                                                  letterSpacing: 0.728,
                                                ),
                                              ),
                                              Spacer(),
                                              Text(
                                                "PM",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: Color.fromARGB(255, 130, 128, 128),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 12,
                                                  letterSpacing: 0.624,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 48,
                                  height: 48,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          width: 15,
                                          height: 15,
                                          margin: EdgeInsets.only(right: 2, bottom: 17),
                                          child: Image.asset(
                                            "assets/images/add.png",
                                            fit: BoxFit.none,
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          width: 48,
                                          height: 16,
                                          child: Image.asset(
                                            "assets/images/group-21.png",
                                            fit: BoxFit.none,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 78,
                          decoration: BoxDecoration(
                            color: AppColors.primaryBackground,
                            borderRadius: BorderRadius.all(Radius.circular(25)),
                          ),
                          child: Container(),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 28,
                    right: 37,
                    bottom: 9,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 17,
                          margin: EdgeInsets.only(bottom: 13),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Text(
                                  "Usage this month",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.accentText,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                    letterSpacing: 0.728,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Text(
                                  "60h",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.secondaryText,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                    letterSpacing: 0.728,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 17,
                          margin: EdgeInsets.only(right: 2),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Text(
                                  "Total usage",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.accentText,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                    letterSpacing: 0.728,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Text(
                                  "160h",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.secondaryText,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                    letterSpacing: 0.728,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}