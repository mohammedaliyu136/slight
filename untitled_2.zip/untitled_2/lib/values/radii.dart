
part of values;


class Radii {
  static const BorderRadiusGeometry k23pxRadius = BorderRadius.all(Radius.circular(23));
}