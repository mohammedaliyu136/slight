
import 'package:flutter/material.dart';
import 'package:untitled_2/android_mobile3_widget/android_mobile3_widget.dart';

void main() => runApp(App());


class App extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
  
    return MaterialApp(
      home: AndroidMobile3Widget(),
    );
  }
}